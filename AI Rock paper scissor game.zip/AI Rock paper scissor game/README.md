# AI Rock Paper Scissor with hand gesture


![Aistonepapaer](https://user-images.githubusercontent.com/81036521/177568863-c82ae583-791a-4b2c-8f6f-ef87acf184a3.JPG)

#
# Introduction

AI Rock Paper Scissor with hand gesture is an AI based python project in which 
you can detect hand and fingers and with the help of your fingers co-ordinates you can figure out if it is an rock,
paper or scissor sign with the help of this you can play this game with the 
AI where the AI plays with the player and the scores are given as per who wins the game. you an start the game by pressing ' s ' on the keyboard per time you play.

### `python3.8 recommended you can try other version too`

```bash
pip install mediapipe
# and
pip install time
# and
pip install math
# and 
pip install numpy
# and
pip install cvzone
# and if any error showed try downgrading 
pip uninstall protobuf
pip install protobuf==3.2.0
```
